# Plan de entregas — Tamagotchi en Python (sin POO)

## Entrega 1 — Análisis, diseño y estructura inicial

### Objetivo
Definir el proyecto y preparar la arquitectura base.

### Debe incluir
- descripción del proyecto  
- reglas del juego  
- estados de la mascota  
- acciones posibles del usuario  
- condiciones de derrota  
- estructura de carpetas  
- lista de módulos previstos  
- primer `main.py` funcional con menú simple  
- creación de la mascota con datos en memoria  

### Archivos esperados
- `main.py`  
- `README.md`  
- posible carpeta base del proyecto  

### Evaluación sugerida
- claridad del diseño  
- estructura inicial correcta  
- programa ejecutable aunque sea simple  

---

## Entrega 2 — Núcleo del juego y ciclo principal

### Objetivo
Implementar la lógica base del Tamagotchi.

### Debe incluir
- mascota representada con diccionario  
- funciones separadas para:  
  - alimentar  
  - jugar  
  - dormir  
  - limpiar  
  - pasar turno  
- menú interactivo funcional  
- actualización de estadísticas  
- muerte de la mascota si la salud llega a 0  
- limitación de valores entre 0 y 100  

### Archivos esperados
- `main.py`  
- `game_logic.py`  
- `utils.py`  

### Evaluación sugerida
- funcionamiento correcto del bucle principal  
- lógica coherente de los estados  
- código modular sin POO  

---

## Entrega 3 — Display avanzado en terminal con ASCII art

### Objetivo
Mejorar la interfaz visual en terminal.

### Debe incluir
- módulo `display.py`  
- limpieza de pantalla  
- barras de estado visuales  
- menús más claros  
- ASCII art según estado o fase de la mascota  
- separación entre lógica y presentación  

### Archivos esperados
- `display.py`  
- carpeta `ascii/` con archivos `.txt`  
- actualización de `main.py`  

### Evaluación sugerida
- terminal clara y agradable  
- uso correcto de ASCII art  
- buena separación entre display y lógica  

---

## Entrega 4 — Persistencia en JSON

### Objetivo
Permitir guardar y cargar la partida.

### Debe incluir
- módulo `storage.py`  
- guardar partida en JSON  
- cargar partida desde JSON  
- inicializar datos desde archivos JSON  
- manejo básico de errores de lectura/escritura  

### Archivos esperados
- `storage.py`  
- carpeta `data/`  
- carpeta `data/saves/`  
- al menos un archivo JSON de ejemplo  

### Evaluación sugerida
- JSON bien estructurado  
- guardado/carga funcional  
- programa recupera correctamente una partida  

---

## Entrega 5 — Datos externos e inventario

### Objetivo
Hacer el juego más dinámico usando archivos de datos.

### Debe incluir
- `mascotas.json`  
- `items.json`  
- selección de tipo de mascota desde JSON  
- inventario básico  
- uso de objetos:  
  - comida  
  - juguetes  
  - medicina  
- modificación de estadísticas según item usado  

### Archivos esperados
- `data/mascotas.json`  
- `data/items.json`  
- actualización de `game_logic.py`  
- actualización de `storage.py`  

### Evaluación sugerida
- datos externos bien cargados  
- inventario funcional  
- acciones influyen correctamente en la mascota  

---

## Entrega 6 — Eventos aleatorios y evolución

### Objetivo
Añadir profundidad al juego.

### Debe incluir
- módulo `events.py`  
- eventos aleatorios por turno  
- evolución por edad o días  
- fases:  
  - bebé  
  - joven  
  - adulto  
- impacto de eventos sobre estadísticas  
- historial simple de eventos  

### Archivos esperados
- `events.py`  
- actualización de `main.py`  
- actualización de `game_logic.py`  

### Evaluación sugerida
- eventos integrados sin romper el flujo  
- evolución visible y coherente  
- jugabilidad más rica  

---

## Entrega 7 — Versión final integrada y pulida

### Objetivo
Entregar una versión completa, estable y defendible.

### Debe incluir
- integración de todos los módulos  
- revisión de errores  
- menús finales  
- mensajes claros  
- validación de entradas  
- README final  
- explicación de módulos  
- explicación de estructura JSON  
- instrucciones de ejecución  

### Archivos esperados
- proyecto completo final  
- `README.md` final  
- estructura limpia y ordenada  

### Evaluación sugerida
- estabilidad  
- calidad del código  
- claridad de organización  
- presentación general  
