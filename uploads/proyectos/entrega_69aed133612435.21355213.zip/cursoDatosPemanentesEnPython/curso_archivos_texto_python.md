# Curso corto: Guardar datos en archivos de texto con Python

## 1. ¿Qué es un archivo de texto?

Un **archivo de texto (.txt)** es un archivo donde se guarda información
en forma de texto.

Ejemplo de archivo:

    Nombre: Ana
    Edad: 20
    Ciudad: Madrid

Python puede crear, leer y modificar estos archivos fácilmente.

------------------------------------------------------------------------

# 2. Abrir un archivo

Para trabajar con archivos usamos la función:

``` python
open(nombre_archivo, modo)
```

Ejemplo:

``` python
archivo = open("datos.txt", "w")
```

### Modos principales

  Modo    Significado
  ------- ----------------------------------------
  `"w"`   escribir (borra el contenido anterior)
  `"a"`   añadir texto al final
  `"r"`   leer el archivo

------------------------------------------------------------------------

# 3. Escribir en un archivo

Ejemplo simple:

``` python
archivo = open("datos.txt", "w")

archivo.write("Hola mundo")

archivo.close()
```

Esto crea un archivo **datos.txt** con:

    Hola mundo

------------------------------------------------------------------------

# 4. Escribir varias líneas

Para crear saltos de línea usamos `\n`.

``` python
archivo = open("datos.txt", "w")

archivo.write("Nombre: Pedro\n")
archivo.write("Edad: 25\n")
archivo.write("Ciudad: Sevilla\n")

archivo.close()
```

Resultado:

    Nombre: Pedro
    Edad: 25
    Ciudad: Sevilla

------------------------------------------------------------------------

# 5. Método recomendado (with)

La forma moderna en Python es usar `with`.

Ventajas: - el archivo se cierra automáticamente - evita errores

``` python
with open("datos.txt", "w") as archivo:
    archivo.write("Hola mundo\n")
    archivo.write("Aprendiendo Python")
```

------------------------------------------------------------------------

# 6. Añadir datos sin borrar lo anterior

Para añadir información usamos el modo `"a"`.

``` python
with open("datos.txt", "a") as archivo:
    archivo.write("\nNueva linea")
```

Si el archivo tenía:

    Hola

Ahora tendrá:

    Hola
    Nueva linea

------------------------------------------------------------------------

# 7. Guardar variables

Podemos guardar datos de variables.

``` python
nombre = "Carlos"
edad = 30

with open("persona.txt", "w") as archivo:
    archivo.write("Nombre: " + nombre + "\n")
    archivo.write("Edad: " + str(edad))
```

Resultado:

    Nombre: Carlos
    Edad: 30

------------------------------------------------------------------------

# 8. Guardar listas

También podemos guardar listas.

``` python
nombres = ["Ana", "Luis", "Pedro", "Maria"]

with open("nombres.txt", "w") as archivo:
    for nombre in nombres:
        archivo.write(nombre + "\n")
```

Archivo generado:

    Ana
    Luis
    Pedro
    Maria

------------------------------------------------------------------------

# 9. Ejercicio

Crear un programa que guarde **3 nombres introducidos por el usuario**.

``` python
with open("usuarios.txt", "w") as archivo:

    for i in range(3):
        nombre = input("Introduce un nombre: ")
        archivo.write(nombre + "\n")
```

------------------------------------------------------------------------

# 10. Ejercicio extra

Crear un programa que guarde:

-   nombre
-   edad
-   ciudad

Ejemplo esperado:

    Nombre: Laura
    Edad: 22
    Ciudad: Valencia

Posible solución:

``` python
nombre = input("Nombre: ")
edad = input("Edad: ")
ciudad = input("Ciudad: ")

with open("persona.txt", "w") as archivo:
    archivo.write("Nombre: " + nombre + "\n")
    archivo.write("Edad: " + edad + "\n")
    archivo.write("Ciudad: " + ciudad + "\n")
```

------------------------------------------------------------------------

# Resumen

En este curso aprendiste:

-   abrir archivos
-   escribir texto en archivos
-   añadir datos
-   guardar variables
-   guardar listas
-   guardar datos introducidos por el usuario

Los archivos de texto son una forma simple de **persistir datos** en
Python.
