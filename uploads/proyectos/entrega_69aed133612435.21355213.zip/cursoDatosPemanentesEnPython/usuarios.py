with open("usuarios.txt", "w") as archivo:

    for i in range(3):
        nombre = input("Introduce un nombre: ")
        archivo.write(nombre + "\n")