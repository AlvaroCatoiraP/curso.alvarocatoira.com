# Curso corto: Introducción a JSON con Python

## 1. ¿Qué es JSON?

**JSON (JavaScript Object Notation)** es un formato muy utilizado para
**guardar y transmitir datos estructurados**.

Se parece mucho a los **diccionarios de Python**.

Ejemplo de JSON:

``` json
{
  "nombre": "Ana",
  "edad": 20,
  "ciudad": "Madrid"
}
```

JSON se usa mucho en: - APIs - configuración de aplicaciones -
almacenamiento de datos - comunicación entre programas

------------------------------------------------------------------------

# 2. Importar el módulo JSON en Python

Python incluye una librería llamada `json`.

``` python
import json
```

Esta librería permite:

-   guardar datos en formato JSON
-   leer archivos JSON

------------------------------------------------------------------------

# 3. Crear un diccionario en Python

Los datos que guardaremos normalmente están en **diccionarios**.

``` python
persona = {
    "nombre": "Carlos",
    "edad": 30,
    "ciudad": "Sevilla"
}
```

------------------------------------------------------------------------

# 4. Guardar datos en un archivo JSON

Usamos `json.dump()` para guardar datos.

``` python
import json

persona = {
    "nombre": "Carlos",
    "edad": 30,
    "ciudad": "Sevilla"
}

with open("persona.json", "w") as archivo:
    json.dump(persona, archivo)
```

Archivo generado:

``` json
{"nombre": "Carlos", "edad": 30, "ciudad": "Sevilla"}
```

------------------------------------------------------------------------

# 5. Hacer el JSON más legible

Podemos usar `indent` para formatear el archivo.

``` python
import json

persona = {
    "nombre": "Carlos",
    "edad": 30,
    "ciudad": "Sevilla"
}

with open("persona.json", "w") as archivo:
    json.dump(persona, archivo, indent=4)
```

Resultado:

``` json
{
    "nombre": "Carlos",
    "edad": 30,
    "ciudad": "Sevilla"
}
```

------------------------------------------------------------------------

# 6. Leer un archivo JSON

Para leer datos usamos `json.load()`.

``` python
import json

with open("persona.json", "r") as archivo:
    datos = json.load(archivo)

print(datos["nombre"])
print(datos["edad"])
```

Salida:

    Carlos
    30

------------------------------------------------------------------------

# 7. Guardar una lista de datos

También podemos guardar **listas de diccionarios**.

``` python
import json

personas = [
    {"nombre": "Ana", "edad": 20},
    {"nombre": "Luis", "edad": 25},
    {"nombre": "Maria", "edad": 22}
]

with open("personas.json", "w") as archivo:
    json.dump(personas, archivo, indent=4)
```

Archivo generado:

``` json
[
    {
        "nombre": "Ana",
        "edad": 20
    },
    {
        "nombre": "Luis",
        "edad": 25
    },
    {
        "nombre": "Maria",
        "edad": 22
    }
]
```

------------------------------------------------------------------------

# 8. Ejercicio

Crea un programa que:

1.  pida nombre y edad al usuario
2.  guarde los datos en un archivo JSON

Ejemplo esperado:

``` json
{
    "nombre": "Laura",
    "edad": 22
}
```

Posible solución:

``` python
import json

nombre = input("Nombre: ")
edad = input("Edad: ")

persona = {
    "nombre": nombre,
    "edad": edad
}

with open("usuario.json", "w") as archivo:
    json.dump(persona, archivo, indent=4)
```

------------------------------------------------------------------------

# Resumen

En este mini curso aprendiste:

-   qué es JSON
-   cómo guardar datos en JSON
-   cómo leer archivos JSON
-   cómo guardar listas de datos

JSON es uno de los formatos más importantes en programación moderna.
