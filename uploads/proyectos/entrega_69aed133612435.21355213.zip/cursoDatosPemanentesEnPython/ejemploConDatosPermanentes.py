import os

if os.path.exists("nombre.txt"):
    
    with open("nombre.txt", "r") as archivo:
        nombre = archivo.read()

    print("Hola de nuevo", nombre)

else:
    
    nombre = input("¿Cómo te llamas? ")

    with open("nombre.txt", "w") as archivo:
        archivo.write(nombre)

    print("Encantado de conocerte", nombre)