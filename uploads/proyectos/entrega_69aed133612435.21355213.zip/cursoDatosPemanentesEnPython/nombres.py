nombre = input("Nombre: ")
edad = input("Edad: ")
ciudad = input("Ciudad: ")

with open("persona.txt", "w") as archivo:
    archivo.write("Nombre: " + nombre + "\n")
    archivo.write("Edad: " + edad + "\n")
    archivo.write("Ciudad: " + ciudad + "\n")