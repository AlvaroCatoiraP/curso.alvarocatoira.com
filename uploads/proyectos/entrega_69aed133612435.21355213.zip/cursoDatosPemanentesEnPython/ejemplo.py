with open("archivo.txt", "w") as archivo:
    archivo.write("Hola, este es un ejemplo de escritura en un archivo.")
